FOTOINDONG — WEBSITE PHOTOGRAPHY & VIDEOGRAPHY

CARA MELIHAT
1. Ekstrak file ZIP.
2. Buka index.html di Chrome/Edge. Internet diperlukan untuk foto contoh Unsplash.

SUDAH DISESUAIKAN
- Brand fotoindong
- Gaya dark cinematic
- Layanan photography, videography, wedding/event, wisuda, prewedding/couple, company profile/produk
- WhatsApp 081233236460 (tautan web menggunakan format 6281233236460)
- Paket harga contoh Rp850.000, Rp1.800.000, Rp2.750.000

Sebelum dipakai:
- Ganti foto contoh dengan portofolio asli yang kamu punya hak untuk gunakan.
- Sesuaikan harga dan isi paket.
- Company profile/foto produk menggunakan penawaran khusus.

PUBLIKASI GRATIS DENGAN GITHUB PAGES
1. Buat akun di https://github.com/
2. Klik + > New repository, beri nama fotoindong, pilih Public, lalu Create repository.
3. Klik Add file > Upload files.
4. Ekstrak ZIP, lalu unggah index.html (README opsional) ke repository.
5. Klik Commit changes.
6. Buka Settings > Pages.
7. Pada Build and deployment, pilih Deploy from a branch.
8. Pilih branch main dan folder /(root), lalu Save.
9. Tunggu beberapa menit. Link biasanya berbentuk https://USERNAME.github.io/fotoindong/

ALTERNATIF NETLIFY DROP
1. Ekstrak ZIP.
2. Buka https://app.netlify.com/drop
3. Seret folder yang berisi index.html ke halaman tersebut.
4. Tunggu hingga Netlify memberi alamat website publik.

Hosting dan subdomain bawaan gratis; domain sendiri biasanya berbayar.
